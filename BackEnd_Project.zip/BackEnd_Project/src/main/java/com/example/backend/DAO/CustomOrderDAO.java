package com.example.backend.DAO;

import com.example.backend.DB.DBConnect;
import com.example.backend.models.CustomOrder;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CustomOrderDAO {
    private static final String INSERT_ORDER_SQL = "INSERT INTO custom_orders" +
            " (full_name, phone, height, weight, message, design_file) VALUES (?, ?, ?, ?, ?, ?)";

    public void saveOrder(CustomOrder order) {
        try (Connection connection = DBConnect.getInstance().getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_ORDER_SQL)) {

            preparedStatement.setString(1, order.getFullName());
            preparedStatement.setString(2, order.getPhone());
            preparedStatement.setString(3, order.getHeight());
            preparedStatement.setString(4, order.getWeight());
            preparedStatement.setString(5, order.getMessage());
            preparedStatement.setString(6, order.getDesignFileName());

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
