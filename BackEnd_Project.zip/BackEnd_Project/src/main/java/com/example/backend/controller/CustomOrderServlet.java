package com.example.backend.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

import jakarta.servlet.http.Part; 

import com.example.backend.DAO.CustomOrderDAO;
import com.example.backend.models.CustomOrder;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/custom-order")
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10,      // 10MB
        maxRequestSize = 1024 * 1024 * 50    // 50MB
)
public class CustomOrderServlet extends HttpServlet {

    private static final String UPLOAD_DIR = "uploads"; // thư mục con trong webapp

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Đảm bảo hỗ trợ tiếng Việt
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        // Lấy thông tin từ form
        String fullName = request.getParameter("fullName");
        String phone = request.getParameter("phone");
        String height = request.getParameter("height");
        String weight = request.getParameter("weight");
        String message = request.getParameter("message");

        // Xử lý file upload (nếu có)
        Part filePart = request.getPart("designFile");
        String fileName = null;

        if (filePart != null && filePart.getSize() > 0) {
            fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

            // Đường dẫn thật đến thư mục /uploads trong webapp
            String uploadPath = request.getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;

            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdir();
            }

            // Lưu file vào thư mục
            filePart.write(uploadPath + File.separator + fileName);
        }

        // Tạo đối tượng đơn đặt may
        CustomOrder order = new CustomOrder(fullName, phone, height, weight, message, fileName);

        // Lưu vào CSDL qua DAO
        CustomOrderDAO dao = new CustomOrderDAO();
        dao.saveOrder(order);

        // Chuyển đến trang cảm ơn
        response.sendRedirect("thankyou.jsp");
    }
}
