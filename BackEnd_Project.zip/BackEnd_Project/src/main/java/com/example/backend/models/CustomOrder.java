package com.example.backend.models;

public class CustomOrder {
    private String fullName;
    private String phone;
    private String height;
    private String weight;
    private String message;
    private String designFileName;

    public CustomOrder(String fullName, String phone, String height, String weight, String message, String designFileName) {
        this.fullName = fullName;
        this.phone = phone;
        this.height = height;
        this.weight = weight;
        this.message = message;
        this.designFileName = designFileName;
    }

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDesignFileName() {
		return designFileName;
	}

	public void setDesignFileName(String designFileName) {
		this.designFileName = designFileName;
	}

    
}

