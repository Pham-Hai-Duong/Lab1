<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="author" content="Untree.co" />
  <link rel="shortcut icon" href="favicon.png" />
  <meta name="description" content="" />
  <meta name="keywords" content="bootstrap, bootstrap4" />

  <!-- Bootstrap CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />
  <link href="css/tiny-slider.css" rel="stylesheet" />
  <link href="css/style.css" rel="stylesheet" />
  <title>Đặt may theo yêu cầu</title>

  <style>
    .form-container {
      background-color: white;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
      margin-top: 50px;
    }

    .form-container h2 {
      text-align: center;
      font-weight: bold;
      margin-bottom: 30px;
    }

    .btn-submit {
      background-color: #c28b51;
      color: white;
      font-weight: bold;
      border: none;
    }

    .btn-submit:hover {
      background-color: #a9743e;
    }
  </style>
</head>

<body>
<!-- Header -->
<div class="header"></div>

<!-- Hero Section -->
<div class="hero">
  <div class="container">
    <div class="row justify-content-between">
      <div class="col-lg-5">
        <div class="intro-excerpt">
          <h1>Đặt may theo yêu cầu</h1>
          <p class="mb-4">
            Chúng tôi luôn sẵn sàng lắng nghe và hỗ trợ bạn! Nếu bạn có bất kỳ câu hỏi nào, yêu cầu hợp tác, hoặc muốn biết thêm thông tin, đừng ngần ngại liên hệ với chúng tôi. Bạn có thể gửi tin nhắn qua mẫu dưới đây hoặc liên hệ qua các kênh thông tin khác. Chúng tôi sẽ phản hồi bạn trong thời gian sớm nhất.
          </p>
          <p><a href="shop.jsp" class="btn btn-secondary me-2">Mua ngay</a></p>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Form Section -->
<div class="container">
  <div class="form-container">
    <h2>ĐẶT MAY THEO YÊU CẦU</h2>
    <form action="custom-order" method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="fullName" class="form-label">Họ và tên</label>
        <input type="text" class="form-control" id="fullName" name="fullName" required />
      </div>

      <div class="mb-3">
        <label for="phone" class="form-label">Số điện thoại</label>
        <input type="text" class="form-control" id="phone" name="phone" required />
      </div>

      <div class="mb-3">
        <label for="height" class="form-label">Chiều cao</label>
        <input type="text" class="form-control" id="height" name="height" required />
      </div>

      <div class="mb-3">
        <label for="weight" class="form-label">Cân nặng</label>
        <input type="text" class="form-control" id="weight" name="weight" required />
      </div>

      <div class="mb-3">
        <label for="designFile" class="form-label">Mẫu cần đặt</label>
        <input type="file" class="form-control" id="designFile" name="designFile" accept=".jpg,.png,.pdf" />
      </div>

      <div class="mb-3">
        <label for="message" class="form-label">Lời nhắn</label>
        <textarea class="form-control" id="message" name="message" rows="3"></textarea>
      </div>

      <button type="submit" class="btn btn-submit">GỬI ĐI</button>
    </form>
  </div>
</div>

<!-- Footer -->
<footer class="footer-section"></footer>

<!-- JS -->
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/tiny-slider.js"></script>
<script src="js/custom.js"></script>
<script src="js/header.jsp"></script>
<script src="js/footer.js"></script>
</body>
</html>
